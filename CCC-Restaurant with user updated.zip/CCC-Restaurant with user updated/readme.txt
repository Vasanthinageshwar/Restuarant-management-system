Username and Passwords 

for admin:

Username: admin@gmail.com;
Password: admin

for user:

Username: user@gmail.com
Password: user

for manager:

Username: manager@gmail.com;
Password: manager